# NOTES.md

## AI Usage Declaration:
- **Tool Used**: ChatGPT (OpenAI)
- **Usage**:
  - Initial code scaffolding and directory structure.
  - Implementing core logic for `models.py` and `utils.py`.
  - Writing Flask routes for URL shortening, redirection, and analytics.
  - Generating unit tests using `pytest`.

## Design Decisions:
- Used **in-memory dictionary** with a **threading.Lock()** to handle concurrent accesses for URL storage.
- Short codes are generated using Python’s `random.choices` (alphanumeric, 6 characters).
- Basic URL validation done using `urllib.parse`.
- No external DBs or caching systems used (per assignment constraints).
- Project structured modularly (`app/` folder with sub-modules for scaling in real applications).

## Test Strategy:
- Functional tests for URL shortening, redirection, and stats.
- Edge cases like invalid URL inputs are covered.
- Health endpoints are also tested.
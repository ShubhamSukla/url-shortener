# TODO: Implement your data models here
# Consider what data structures you'll need for:
# - Storing URL mappings
# - Tracking click counts
# - Managing URL metadata

import threading
from datetime import datetime, timezone

class URLStore:
    def __init__(self):
        self.url_mapping = {}  # short_code -> { 'url': str, 'clicks': int, 'created_at': datetime }
        self.lock = threading.Lock()

    def save_url(self, short_code, long_url):
        with self.lock:
            self.url_mapping[short_code] = {
                'url': long_url,
                'clicks': 0,
                'created_at': datetime.now(timezone.utc)
            }

    def get_url(self, short_code):
        with self.lock:
            return self.url_mapping.get(short_code)

    def increment_click(self, short_code):
        with self.lock:
            if short_code in self.url_mapping:
                self.url_mapping[short_code]['clicks'] += 1
                return True
            return False

    def get_stats(self, short_code):
        with self.lock:
            return self.url_mapping.get(short_code)
